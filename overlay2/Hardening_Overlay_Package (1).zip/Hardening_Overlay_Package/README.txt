HARDENING / OVERLAY PACKAGE - lindungi SD card Raspberry tanpa mengubah kode broker
Protect the Raspberry Pi SD card without changing any broker code

PILIH SATU / CHOOSE ONE
  A_HARDENING        (REKOMENDASI / RECOMMENDED)  tanpa overlay, data selalu permanen
                     no overlay, all data always persistent.
                     Panduan / Guide: docs/ID/A1_*.pdf  |  docs/EN/A1_*.pdf
  B_OVERLAY_PERSIST  overlay + HANYA config.json, bridge.conf, hostname permanen (status/rfid/log di RAM). BELUM DIUJI di Raspberry fisik -> UJI DI BENCH DULU.
                     overlay + ONLY config.json, bridge.conf, hostname persistent (status/rfid/logs in RAM). NOT TESTED on a physical Pi -> BENCH TEST FIRST.
                     Panduan / Guide: docs/ID/B1_*.pdf  |  docs/EN/B1_*.pdf

JANGAN pasang A dan B sekaligus. / Do NOT install A and B together.

LANGKAH SINGKAT A (detail: A1)
  1. findmnt -no FSTYPE /   -> ext4 (overlay mati / overlay off)
  2. Salin ISI A_HARDENING ke /home/alice/broker/ (tidak ada file lama yang ditimpa / no existing file is overwritten)
  3. cd /home/alice/broker && chmod +x harden_sd.sh && sudo ./harden_sd.sh && sudo reboot
  4. findmnt /home/alice/broker/logs  -> tmpfs

LANGKAH SINGKAT B (detail: B1)
  1. findmnt -no FSTYPE /   -> ext4
  2. Salin ISI B_OVERLAY_PERSIST ke /home/alice/broker/
  3. chmod +x *.sh overlay_persist/broker-persist && sudo ./setup_overlay_persist.sh
  4. sudo raspi-config nonint do_overlayfs 0 && sudo reboot
  5. Jalankan semua tes di B1 bagian 5 / Run all tests in B1 section 5
  Matikan overlay / disable overlay: sudo raspi-config nonint do_overlayfs 1 && sudo reboot
  Update broker saat overlay aktif / update with overlay on: sudo ./update_broker.sh /home/alice/new_broker

docs/*/A2_*  langkah lanjutan OPSIONAL (cmdline.txt) - berisiko, tidak perlu / optional, risky, not needed
docs/*/C*    perbandingan overlay vs hardening / comparison

Buat image cadangan SD card sebelum memulai jika memungkinkan. / Make an SD card image backup first if possible.


=== UPDATE: B_OVERLAY_PERSIST (master -> clone workflow) ===
- broker-persist now also saves /etc/hostname and /etc/netplan/*.yaml together with bridge.conf (mode 'net').
- setup_overlay_persist.sh: ipservice waits for dip.service + 30 s and saves the network profile before reading the IP.
- check_overlay_persist.sh: read-only status check (run: sudo ./check_overlay_persist.sh).
- docs: B1 (master preparation + tests T1-T7 + cloning), D1 (one-page technician guide, no commands).
- MUST verify on the master that a DIP change rewrites /etc/netplan/*.yaml BEFORE enabling overlay (B1 section 4).
- Code limits: dip.py = 4 bits (.101-.115), ipservice.py = .101-.126 (A-Z); 40 cabinets exceed both.
- Not tested on real hardware. Bench-test the master and one cloned SD first.
