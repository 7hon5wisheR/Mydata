WEB OVERLAY TOGGLE (apps.py + templates/index.html)
====================================================
ID: Tombol Overlay Enable/Disable di halaman web http://IP:8082 -> klik ikon gear (Advanced Settings),
    form baru ada di bawah "Logger". Pilih Enable/Disable -> Apply & Reboot -> konfirmasi.
EN: Overlay enable/disable form in the hidden Advanced Settings section (gear icon), below "Logger".

Perubahan / Changes (only these two files; everything else in the broker is untouched):
 - apps.py: + normalize_overlay(), is_overlay_active(), apply_overlay_change(); the broker-form condition now also ignores
   form_name=overlay_toggle; new overlay_toggle handler; template vars overlay_active, overlay_message.
 - templates/index.html: new overlay form, badge, confirm dialog.
 - Runs: sudo raspi-config nonint do_overlayfs 0 (enable) / 1 (disable), then the same reboot path (reboot_after_delay).
 - If already in the requested state: nothing runs, no reboot. Server also requires the confirm flag.
 - NOT available via REST (/api/config) or MQTT - web form only.

Pasang / Deploy:
 - Overlay OFF : copy apps.py to /home/alice/broker/ and index.html to /home/alice/broker/templates/ ; sudo reboot
 - Overlay ON  : put them in a folder together with the rest of the broker and use update_broker.sh (B_OVERLAY_PERSIST)

Catatan / Notes:
 - Requires passwordless sudo for raspi-config (apps.py already uses sudo for reboot/hostname/systemctl).
 - Tested only with a mocked subprocess (Flask test client). NOT tested on a real Pi: bench-test enable AND disable
   (disable must work while the overlay is active; raspi-config needs to write the boot partition).
 - Security: the page has no login (same as the existing page). Anyone who can reach :8082 can toggle the overlay.
