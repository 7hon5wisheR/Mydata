#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# sublight.py
# Modul kontrol lampu PWM: sub_on() / sub_off().
#
# LINTAS PROSES - PAKAI status.json YANG SUDAH ADA:
#   lightLockControl.py jalan sebagai service sendiri, terpisah dari
#   run.py/mqtts.py. Supaya status lampu tetap kebaca proses lain
#   TANPA bikin file baru (status.json sudah dikirim ke web, jangan
#   sampai ada 2 sumber status yang perlu disinkronkan manual), modul
#   ini langsung baca/tulis field "Light" di status.json yang SUDAH
#   ADA - field yang sama yang sudah dipakai status.py selama ini.
#   Field lain di status.json (Door1, Lock1, sessionId, dst) tidak
#   disentuh - read-modify-write, cuma key "Light" yang diubah.
#
# CATATAN KEY CONFIG BRIGHTNESS:
#   config.json pakai key "dim" (bukan "brightness"), skala TERBALIK:
#     dim = 0    -> paling terang -> PWM duty = 100%
#     dim = 100  -> paling redup  -> PWM duty = 0%
#   sub_on() baca "dim" lalu invert jadi PWM duty. sub_off() TIDAK
#   PERNAH menulis config.json - dim yang tersimpan tetap utuh.

import json
import os
import threading
import time
import RPi.GPIO as GPIO
from mutex import FileMutex

from logger import get_logger
log = get_logger("sublight")

# =====================================================
# GPIO CONFIG
# =====================================================
ENABLE_GPIO = 16   # driver enable / power gate pin
PWM_GPIO    = 18   # PWM signal pin (brightness control)
PWM_FREQ_HZ = 1000

BASE_DIR    = os.path.dirname(os.path.abspath(__file__))
CONFIG_PATH = os.path.join(BASE_DIR, "config.json")
STATUS_PATH = os.path.join(BASE_DIR, "status.json")   # file yang SUDAH ADA, dipakai ulang

DIM_MIN = 0
DIM_MAX = 100

GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
GPIO.setup(ENABLE_GPIO, GPIO.OUT)
GPIO.setup(PWM_GPIO, GPIO.OUT)

_pwm = GPIO.PWM(PWM_GPIO, PWM_FREQ_HZ)
_pwm.start(0)
GPIO.output(ENABLE_GPIO, GPIO.LOW)

# Mutex nama "light" - sama dengan light.py lama, tetap eksklusif
# akses GPIO fisik antar-thread dalam proses ini.
_mutex = FileMutex("light")


def set_pwm(value):
    """Set raw PWM duty cycle (0-100) + toggle enable pin sesuai nilai."""
    value = max(0, min(100, int(value)))
    if value <= 0:
        _pwm.ChangeDutyCycle(0)
        GPIO.output(ENABLE_GPIO, GPIO.LOW)
    else:
        GPIO.output(ENABLE_GPIO, GPIO.HIGH)
        _pwm.ChangeDutyCycle(value)


def _read_configured_brightness() -> int:
    """
    Baca 'dim' dari config.json (live, tiap dipanggil), invert jadi
    PWM duty. Default 100% (paling terang) kalau config.json
    tidak ada / rusak / field kosong.
    """
    try:
        with open(CONFIG_PATH) as f:
            cfg = json.load(f)
        dim = int(cfg.get("dim", 0))
    except Exception as e:
        log.warning("[SUBLIGHT] Gagal baca 'dim' dari %s: %s. Default dim=0 (paling terang).",
                    CONFIG_PATH, e)
        dim = 0

    dim = max(DIM_MIN, min(DIM_MAX, dim))
    return DIM_MAX - dim   # dim=0 -> 100% ; dim=100 -> 0%


# =====================================================
# BACA/TULIS FIELD "Light" DI status.json (bukan file baru)
# Read-modify-write: hanya key "Light" yang diubah, field lain
# (Door1, Lock1, sessionId, Temperature, dst - yang ditulis oleh
# status.py di proses run.py/mqtts.py) dibiarkan apa adanya.
# =====================================================
def _update_status_light(state: str):
    try:
        st = {}
        if os.path.exists(STATUS_PATH):
            with open(STATUS_PATH) as f:
                st = json.load(f)
        st["Light"] = state
        with open(STATUS_PATH, "w") as f:
            json.dump(st, f, indent=2)
    except Exception as e:
        log.error("[SUBLIGHT] Gagal update 'Light' di %s: %s", STATUS_PATH, e)


def get_light_status() -> str:
    """
    Dipanggil status.py sebagai pengganti light.get_light_status().
    Baca field "Light" langsung dari status.json (file yang sama
    yang sudah dikirim ke web) - bukan file terpisah.
    """
    try:
        if os.path.exists(STATUS_PATH):
            with open(STATUS_PATH) as f:
                st = json.load(f)
            s = st.get("Light", "Off")
            if s in ("On", "Off"):
                return s
    except Exception as e:
        log.warning("[SUBLIGHT] Gagal baca 'Light' dari %s: %s", STATUS_PATH, e)
    return "Off"


# =====================================================
# PUBLIC API - permanent ON/OFF
# =====================================================
def sub_on():
    """
    Baca konfigurasi brightness (config.json['dim']) lalu set PWM.
    TIDAK PERNAH menulis config.json. Update field "Light" di
    status.json yang sudah ada supaya proses lain tahu status terkini.
    """
    _mutex.acquire(wait=True, owner="LIGHT")
    try:
        brightness = _read_configured_brightness()
        set_pwm(brightness)
        _update_status_light("On")
        print(f"SUB ON -> brightness {brightness}%")
        log.info("[SUBLIGHT] ON -> brightness %s%%", brightness)
    finally:
        _mutex.release(owner="LIGHT")


def sub_off():
    """
    Paksa brightness ke 0%. TIDAK PERNAH menulis config.json - nilai
    'dim' tersimpan tetap utuh untuk sub_on() berikutnya.
    """
    _mutex.acquire(wait=True, owner="LIGHT")
    try:
        set_pwm(0)
        _update_status_light("Off")
        print("SUB OFF -> brightness 0%")
        log.info("[SUBLIGHT] OFF -> brightness 0%%")
    finally:
        _mutex.release(owner="LIGHT")


# =====================================================
# PUBLIC API - timed ON/OFF
# (dibutuhkan lightLockControl.py, sebelumnya pakai
# light.light_set(state, seconds=...))
# =====================================================
def sub_on_for(seconds):
    def _worker():
        _mutex.acquire(wait=True, owner="LIGHT")
        try:
            brightness = _read_configured_brightness()
            set_pwm(brightness)
            _update_status_light("On")
            print(f"SUB ON for {seconds}s -> brightness {brightness}%")
            time.sleep(seconds)
        finally:
            set_pwm(0)
            _update_status_light("Off")
            _mutex.release(owner="LIGHT")
    threading.Thread(target=_worker, daemon=True).start()


def sub_off_for(seconds):
    def _worker():
        _mutex.acquire(wait=True, owner="LIGHT")
        try:
            set_pwm(0)
            _update_status_light("Off")
            print(f"SUB OFF for {seconds}s -> brightness 0%")
            time.sleep(seconds)
        finally:
            _mutex.release(owner="LIGHT")
    threading.Thread(target=_worker, daemon=True).start()


def sub_set(state, seconds=None):
    """Convenience wrapper, drop-in pengganti light.light_set(state, seconds)."""
    if seconds:
        if state:
            sub_on_for(float(seconds))
        else:
            sub_off_for(float(seconds))
    else:
        if state:
            sub_on()
        else:
            sub_off()
    return True
