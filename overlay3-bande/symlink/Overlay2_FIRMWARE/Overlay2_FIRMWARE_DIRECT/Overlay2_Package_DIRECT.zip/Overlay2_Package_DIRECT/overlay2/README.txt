Overlay2 1.0.0.(18) - DIRECT version - Saifuddin
DIRECT = the broker code itself reads config.json and conf.d/bridge.conf from the persistent store (/boot/firmware/broker),
read from /etc/overlay2.conf. There are NO symlinks and NO copies of these two files in /home/alice/broker.
(7 files read the store: apps.py ipservice.py library/logger.py reader.py status.py sublight.py utilitys.py)
Volatile SD (overlay) + persistent store on the FAT boot partition. Hostname + IP restored at boot from bridge.conf.

Install:
cd ~/broker/overlay2
sudo bash ./install_all.sh        # Pi reboots 2x by itself (~3 min)
sudo bash ./install_all.sh        # after SSH is back: final check -> RESULT: ALL OK

Needs the broker from Broker_with_Overlay2_DIRECT.zip (setup refuses to run with the old, non-direct broker code).
