# LED Status (8 LED) - cadangan jika monitor React rusak

File baru (kode lama TIDAK diubah): `ledstatus.py`, `ledstatus.service`, `LED_README.md`

## Wiring (BCM, tiap LED + resistor 330 ohm ke GND)

| LED | GPIO | Pin fisik | Menyala jika |
|-----|------|-----------|--------------|
| 1 Door Open  | 4  | 7  | pintu terbuka |
| 2 Door Close | 12 | 32 | pintu tertutup |
| 3 Lock       | 13 | 33 | terkunci |
| 4 Unlock     | 25 | 22 | tidak terkunci |
| 5 Light On   | 19 | 35 | lampu On |
| 6 Light Off  | 20 | 38 | lampu Off |
| 7 Scanning   | 21 | 40 | **berkedip** saat scanning |
| 8 Ready      | 7  | 26 | status Ready |

Semua LED berkedip bersamaan = cabinet sedang reboot.
Pin ini tidak dipakai modul lain (terpakai: 2,3,5,6,14,15,16,17,18,22,23,24,26,27).
Jika LED dihubungkan ke 3.3V (active-low), atau ingin ganti pin, tambahkan di config.json:
`"led_pins": [4,12,13,25,19,20,21,7], "led_active_low": true`

## Pasang
```bash
cd /home/alice/broker
python3 ledstatus.py --test        # tes wiring: 8 LED menyapu satu per satu
sudo cp ledstatus.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now ledstatus
journalctl -u ledstatus -f
```
Jika `User=alice` tidak bisa akses GPIO, ganti jadi `User=root` (seperti ipservice.service).
Service ini independen dari send.service, jadi LED tetap hidup walau salah satu modul lain restart.
