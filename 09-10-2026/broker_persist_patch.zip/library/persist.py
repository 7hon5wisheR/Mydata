# persist.py
# -*- coding: utf-8 -*-
"""
Penyimpanan data yang AMAN dari mati lampu, untuk Raspberry Pi dengan overlay (root read-only).

- Semua file data (config.json, status.json, rfid1/2.json, tag_debounce_state.json,
  conf.d/bridge.conf) disimpan di DATA_DIR.
- Di Raspberry (partisi /data ter-mount) -> DATA_DIR = /data/broker  (ext4, tulis permanen).
- Di PC/Mac (pengembangan) atau kalau /data belum ada -> DATA_DIR = folder broker biasa
  (perilaku lama; akan ada peringatan di log bila di Raspberry dengan overlay).
- Penulisan ATOMIK: tulis ke file sementara -> flush -> fsync -> rename -> fsync folder.
  Saat mati lampu isinya selalu "versi lama utuh" ATAU "versi baru utuh", tidak pernah setengah.
- Override manual: environment variable BROKER_DATA_DIR.
"""
import os
import json
import shutil

_LIB_DIR  = os.path.dirname(os.path.abspath(__file__))
BASE_DIR  = os.path.abspath(os.path.join(_LIB_DIR, ".."))   # folder broker (kode + file default)
DATA_MOUNT = "/data"


def _resolve_data_dir():
    env = os.environ.get("BROKER_DATA_DIR")
    if env:
        return env
    if os.path.ismount(DATA_MOUNT):
        return os.path.join(DATA_MOUNT, "broker")
    return BASE_DIR


DATA_DIR = _resolve_data_dir()
PERSISTENT = (DATA_DIR != BASE_DIR)
CONF_DIR = os.path.join(DATA_DIR, "conf.d")


def data_path(*parts):
    """Path lengkap file data, mis. data_path('config.json')."""
    return os.path.join(DATA_DIR, *parts)


def _fsync_dir(d):
    try:
        fd = os.open(d, os.O_RDONLY)
        try:
            os.fsync(fd)
        finally:
            os.close(fd)
    except OSError:
        pass


def atomic_write_text(path, text, mode=None):
    d = os.path.dirname(os.path.abspath(path))
    os.makedirs(d, exist_ok=True)
    tmp = os.path.join(d, "." + os.path.basename(path) + ".tmp.%d" % os.getpid())
    try:
        with open(tmp, "w") as f:
            f.write(text)
            f.flush()
            os.fsync(f.fileno())
        if mode is not None:
            os.chmod(tmp, mode)
        os.replace(tmp, path)
        _fsync_dir(d)
    finally:
        if os.path.exists(tmp):
            try:
                os.remove(tmp)
            except OSError:
                pass


def atomic_write_json(path, obj, indent=2):
    atomic_write_text(path, json.dumps(obj, indent=indent))


def seed_defaults(names=("config.json", "status.json", "rfid1.json", "rfid2.json",
                         "tag_debounce_state.json"), conf_dir_name="conf.d"):
    """
    Dipanggil sekali saat start. Jika file belum ada di DATA_DIR, salin dari
    folder broker (default bawaan image). Tidak pernah menimpa file yang sudah ada.
    """
    if not PERSISTENT:
        return
    os.makedirs(DATA_DIR, exist_ok=True)
    for n in names:
        src, dst = os.path.join(BASE_DIR, n), os.path.join(DATA_DIR, n)
        if os.path.exists(src) and not os.path.exists(dst):
            shutil.copy2(src, dst)
    src_c, dst_c = os.path.join(BASE_DIR, conf_dir_name), os.path.join(DATA_DIR, conf_dir_name)
    os.makedirs(dst_c, exist_ok=True)
    if os.path.isdir(src_c):
        for n in os.listdir(src_c):
            s, t = os.path.join(src_c, n), os.path.join(dst_c, n)
            if os.path.isfile(s) and not os.path.exists(t):
                shutil.copy2(s, t)
