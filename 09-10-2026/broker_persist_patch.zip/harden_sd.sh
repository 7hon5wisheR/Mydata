#!/bin/bash
# ================================================================
#  harden_sd.sh -- lindungi SD card dari korup saat mati lampu
#  (TANPA overlay, TANPA partisi baru). Aman dijalankan berulang.
#  Pakai:  sudo ./harden_sd.sh        lalu:  sudo reboot
# ================================================================
set -e
HOME_BASE="alice"
BROKER_DIR="/home/${HOME_BASE}/broker"
[ "$EUID" -eq 0 ] || { echo "Jalankan dengan sudo"; exit 1; }

if [ "$(findmnt -no FSTYPE /)" = "overlay" ]; then
  echo "Overlay aktif. Matikan dulu: sudo raspi-config nonint do_overlayfs 1 && sudo reboot"; exit 1
fi

CMD=/boot/firmware/cmdline.txt; [ -f "$CMD" ] || CMD=/boot/cmdline.txt
FSTAB=/etc/fstab
cp -n "$CMD" "$CMD.bak"; cp -n "$FSTAB" "$FSTAB.bak"

echo "[1] ext4 journal data + commit 1 detik (cmdline.txt)"
if ! grep -q "rootflags=" "$CMD"; then
  sed -i '1 s/$/ rootflags=data=journal,commit=1/' "$CMD"
fi

echo "[2] noatime di fstab"
sed -i -E '/^[^#].*[[:space:]](\/|\/boot\/firmware|\/boot)[[:space:]]+(ext4|vfat)/ { /noatime/! s/defaults/defaults,noatime/ }' "$FSTAB"

echo "[3] logs aplikasi ke RAM"
UID_=$(id -u $HOME_BASE); GID_=$(id -g $HOME_BASE)
mkdir -p "$BROKER_DIR/logs"
grep -q "$BROKER_DIR/logs" "$FSTAB" || \
  echo "tmpfs $BROKER_DIR/logs tmpfs defaults,noatime,size=32m,uid=$UID_,gid=$GID_,mode=0755 0 0" >> "$FSTAB"

echo "[4] journal sistem ke RAM"
mkdir -p /etc/systemd/journald.conf.d
printf "[Journal]\nStorage=volatile\nRuntimeMaxUse=20M\n" > /etc/systemd/journald.conf.d/volatile.conf

echo "[5] matikan swap"
dphys-swapfile swapoff 2>/dev/null || true
systemctl disable dphys-swapfile 2>/dev/null || true

echo "[6] mosquitto: tanpa persistence & log file"
M=/etc/mosquitto/mosquitto.conf
if [ -f "$M" ]; then
  cp -n "$M" "$M.bak"
  sed -i 's#^persistence true#persistence false#; s#^log_dest file .*#log_dest syslog#' "$M"
  systemctl restart mosquitto || true
fi

echo "Selesai. Sekarang: sudo reboot"
echo "Cek setelah reboot: cat /proc/cmdline | grep data=journal ; findmnt $BROKER_DIR/logs"
